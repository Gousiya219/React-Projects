import React from "react";
import Checkbox from "@mui/material/Checkbox";
import "./ToDoApp.css"; // Import the CSS file

function ToDoApp() {
  const [tasks, setTasks] = React.useState([
    { text: "Go Home", completed: false },
    { text: "Eat Food", completed: false },
    { text: "Sleep", completed: false },
  ]);
  const [task, setTask] = React.useState("");

  const addTask = () => {
    if (task.trim() !== "") {
      setTasks([...tasks, { text: task, completed: false }]);
      setTask("");
    }
  };

  const handleCheckboxClick = (index) => {
    setTasks((prevTasks) =>
      prevTasks.map((task, i) =>
        i === index ? { ...task, completed: !task.completed } : task
      )
    );
  };

  return (
    <div className="todo-container">
      <h1 className="todo-title">My To-Do List</h1>
      <div className="todo-input-container">
        <input
          className="todo-input"
          type="text"
          value={task}
          placeholder="Add New Task"
          onChange={(e) => setTask(e.target.value)}
        />
        <button className="todo-add-button" onClick={addTask}>
          Add Task
        </button>
      </div>
      <ul className="todo-list">
        {tasks.map((task, index) => (
          <li key={index} className="todo-item">
            <Checkbox
              checked={task.completed}
              onChange={() => handleCheckboxClick(index)}
              size="small"
            />
            <span
              className={`todo-text ${
                task.completed ? "todo-completed" : ""
              }`}
            >
              {task.text}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ToDoApp;
